package com.cg.service;
import com.cg.bean.*;
import com.cg.controller.Conn;
import com.cg.dao.NewUserDao;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class NewUser extends HttpServlet{

	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{	Connection c=null;
		PreparedStatement pst=null;
		Conn c1=new Conn();
		RequestDispatcher rd=null;
		UserBean bean=new UserBean();
		String uname=req.getParameter("username");
		String pwd=req.getParameter("password");
		String role=req.getParameter("role");
		bean.setUserName(uname);
		bean.setPassWord(pwd);
		bean.setRoleCode(role);
		PrintWriter out=res.getWriter();
	if(role.equals("role"))
	{
		out.print("enter again");
		rd=req.getRequestDispatcher("/ProfileCreation.jsp");
		rd.forward(req, res);
	}else {
		try {
			c=c1.getCon();
			String sql="insert into userrole values (?,?,?)";
			pst=c.prepareStatement(sql);
			pst.setString(1,bean.getUserName());
			pst.setString(2,bean.getPassWord());
			pst.setString(3,bean.getRoleCode());
			pst.executeQuery();
			
			
			rd=req.getRequestDispatcher("/SuccessUserCreated.jsp");
			rd.forward(req,res);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}}
	
	
}
