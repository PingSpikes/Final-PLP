package com.cg.dao;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.bean.UserBean;
import com.cg.controller.Conn;


public class NewUserDao {
	Connection c=null;
	PreparedStatement pst=null;
	Conn c1=new Conn();
	HttpServletRequest req=null; HttpServletResponse res=null;
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		PrintWriter out=res.getWriter();
		out.print("<html><body>fuck uuu....</body></html>");
	}
	public void addUser(UserBean bean) throws Exception
	{
		
		c=c1.getCon();
		String sql="insert into userrole values (?,?,?)";
		pst=c.prepareStatement(sql);
		pst.setString(1,bean.getUserName());
		pst.setString(2,bean.getPassWord());
		pst.setString(3,bean.getRoleCode());
		pst.executeQuery();
		
		NewUserDao obj=new NewUserDao();
		obj.doGet(req, res);
				
				
				
				
				
	
		
	}
}
